INSERT INTO tb_log (id, model_name, model_value, return_value, return_class, operate_user, operate_time, param_and_value, operate_class, operate_method, cost_time, source)
VALUES ('1', 'user', 'insert', 'success', 'java.lang.String', '10001', '2022-01-06 18:12:28', '{"age":"20","name":"Tom","gender":"1"}', 'cn.itcast.controller.UserController', 'insert', '10', 1);

INSERT INTO tb_log (id, model_name, model_value, return_value, return_class, operate_user, operate_time, param_and_value, operate_class, operate_method, cost_time, source)
VALUES ('2', 'user', 'insert', 'success', 'java.lang.String', '10001', '2022-01-06 18:12:27', '{"age":"20","name":"Tom","gender":"1"}', 'cn.itcast.controller.UserController', 'insert', '23', 2);

INSERT INTO tb_log (id, model_name, model_value, return_value, return_class, operate_user, operate_time, param_and_value, operate_class, operate_method, cost_time, source)
VALUES ('3', 'user', 'update', 'success', 'java.lang.String', '10001', '2022-01-06 18:16:45', '{"age":"20","name":"Tom","gender":"1"}', 'cn.itcast.controller.UserController', 'update', '34', 3);

INSERT INTO tb_log (id, model_name, model_value, return_value, return_class, operate_user, operate_time, param_and_value, operate_class, operate_method, cost_time, source)
VALUES ('4', 'user', 'update', 'success', 'java.lang.String', '10001', '2022-01-06 18:16:45', '{"age":"20","name":"Tom","gender":"1"}', 'cn.itcast.controller.UserController', 'update', '13', 4);

INSERT INTO tb_log (id, model_name, model_value, return_value, return_class, operate_user, operate_time, param_and_value, operate_class, operate_method, cost_time, source)
VALUES ('5', 'user', 'insert', 'success', 'java.lang.String', '10001', '2022-01-06 18:30:31', '{"age":"200","name":"TomCat","gender":"0"}', 'cn.itcast.controller.UserController', 'insert', '29', 5);

INSERT INTO tb_log (id, model_name, model_value, return_value, return_class, operate_user, operate_time, param_and_value, operate_class, operate_method, cost_time, source)
VALUES ('6', 'user', 'find', 'success', 'java.lang.String', '10001', '2022-01-06 18:30:31', '{"age":"200","name":"TomCat","gender":"0"}', 'cn.itcast.controller.UserController', 'find', '29', 6);
