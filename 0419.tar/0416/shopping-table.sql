-- 创建数据库（如果需要）
CREATE DATABASE IF NOT EXISTS shopping CHARSET utf8;

USE SHOPPING;

-- 创建品牌表
CREATE TABLE tb_goods_brand (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
) CHARSET utf8;

-- 创建分类表
CREATE TABLE tb_goods_cat (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
) CHARSET utf8;

-- 创建商品基础信息表
CREATE TABLE tb_goods_base (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2),
    brand_id INT,
    cat_id INT,
    FOREIGN KEY (brand_id) REFERENCES tb_goods_brand(id),
    FOREIGN KEY (cat_id) REFERENCES tb_goods_cat(id)
) CHARSET utf8;

-- 创建商品描述表
CREATE TABLE tb_goods_desc (
    goods_id INT PRIMARY KEY,
    description TEXT,
    FOREIGN KEY (goods_id) REFERENCES tb_goods_base(id)
) CHARSET utf8;


CREATE TABLE tb_goods_item (
    id INT PRIMARY KEY AUTO_INCREMENT,  -- 商品项ID，自动递增
    goods_id INT NOT NULL,              -- 关联的商品基础信息ID
    spec_info VARCHAR(255),             -- 规格信息，例如颜色、尺寸等
    price DECIMAL(10, 2) NOT NULL,      -- 此规格商品的价格
    stock INT DEFAULT 0,                -- 库存数量
    sku_code VARCHAR(50) UNIQUE,        -- SKU编码，唯一标识每个规格的商品
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- 创建时间
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- 更新时间
    FOREIGN KEY (goods_id) REFERENCES tb_goods_base(id) ON DELETE CASCADE  -- 外键约束，关联到商品基础信息表
) CHARSET utf8;




-- 创建订单明细表
CREATE TABLE tb_order_item (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    goods_id INT,
    quantity INT
) CHARSET utf8;

-- 创建主订单表
CREATE TABLE tb_order_master (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    total_amount DECIMAL(10, 2),
    status TINYINT,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) CHARSET utf8;

-- 创建支付日志表
CREATE TABLE tb_order_pay_log (
    out_trade_no VARCHAR(64) PRIMARY KEY,
    order_id INT,
    pay_status TINYINT,
    transaction_id VARCHAR(64),
    pay_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) CHARSET utf8;







-- 创建用户表
CREATE TABLE tb_user (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    status TINYINT
) CHARSET utf8;

-- 创建省市区表
CREATE TABLE tb_areas_provinces (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
) CHARSET utf8;

CREATE TABLE tb_areas_city (
    id INT PRIMARY KEY,
    province_id INT,
    name VARCHAR(255) NOT NULL,
    FOREIGN KEY (province_id) REFERENCES tb_areas_provinces(id)
) CHARSET utf8;

CREATE TABLE tb_areas_region (
    id INT PRIMARY KEY,
    city_id INT,
    name VARCHAR(255) NOT NULL,
    FOREIGN KEY (city_id) REFERENCES tb_areas_city(id)
) CHARSET utf8;


-- 创建用户地址表
CREATE TABLE tb_user_address (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    province_id INT,
    city_id INT,
    region_id INT,
    detail_address VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES tb_user(id),
    FOREIGN KEY (province_id) REFERENCES tb_areas_provinces(id),
    FOREIGN KEY (city_id) REFERENCES tb_areas_city(id),
    FOREIGN KEY (region_id) REFERENCES tb_areas_region(id)
) CHARSET utf8;
