SELECT *
FROM tb_goods_base t1
JOIN tb_areas_provinces t2
JOIN tb_areas_city t3
JOIN tb_areas_region t4;

SELECT *
FROM tb_user t1
JOIN tb_areas_provinces t2
JOIN tb_areas_city t3
JOIN tb_areas_region t4;
