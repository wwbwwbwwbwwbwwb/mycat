USE SHOPPING;

-- 插入品牌数据
INSERT INTO tb_goods_brand (name) VALUES ('Brand A'), ('Brand B');

-- 插入分类数据
INSERT INTO tb_goods_cat (name) VALUES ('Category 1'), ('Category 2');

-- 插入商品基础信息数据
INSERT INTO tb_goods_base (name, price, brand_id, cat_id) VALUES 
('Product 1', 99.99, 1, 1),
('Product 2', 199.99, 2, 2);

-- 插入商品描述数据
INSERT INTO tb_goods_desc (goods_id, description) VALUES 
(1, 'This is Product 1'),
(2, 'This is Product 2');


-- 插入省市区数据
INSERT INTO tb_areas_provinces (id, name) VALUES (1, 'Province A'), (2, 'Province B');
INSERT INTO tb_areas_city (id, province_id, name) VALUES (1, 1, 'City A1'), (2, 2, 'City B1');
INSERT INTO tb_areas_region (id, city_id, name) VALUES (1, 1, 'Region A1'), (2, 2, 'Region B1');

-- 插入用户数据
INSERT INTO tb_user (username, password, phone, address, status) VALUES 
('user1', 'password1', '1234567890', 'Address 1', 1),
('user2', 'password2', '0987654321', 'Address 2', 1);

-- 插入用户地址数据
INSERT INTO tb_user_address (user_id, province_id, city_id, region_id, detail_address) VALUES 
(1, 1, 1, 1, 'Detail Address 1 for User 1'),
(2, 2, 2, 2, 'Detail Address 2 for User 2');

